import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import {connect} from 'react-redux'
class App extends Component {
  state={
    data:[],
    name:"",
    age:"",
    transgender:"",
    selecteditems:[],
    itactive:false,
    bankactive:false,
    Bussinessavtive:false,
    Railwaysactive:false,
  }
  submit=()=>{
    let singledata = {
      name : this.state.name,
      age : this.state.age,
      items:this.state.selecteditems,
  }
    this.setState({
      data:[...this.state.data,singledata],
      name:"",
      age:"",
      transgender:"",
      itactive:false,
      bankactive:false,
      Bussinessavtive:false,
      Railwaysactive:false,
      selecteditems:[],
    })
    this.props.sendData(singledata)
  }

  IT=(e)=>{
    if(this.state.itactive){
      this.setState ({
        itactive: false
      })
      }else if(!this.state.itactive){
        this.setState ({
          itactive: true,
          selecteditems:[...this.state.selecteditems,e.target.value]
        })
  
      }
  }

  business=(e)=>{
    if(this.state.Bussinessavtive){
      this.setState ({
        Bussinessavtive: false
      })
      }else if(!this.state.Bussinessavtive){
        this.setState ({
          Bussinessavtive: true,
          selecteditems:[...this.state.selecteditems,e.target.value]
        })
  
      }
  
  }

  banking=(e)=>{
    if(this.state.bankactive){
      this.setState ({
        bankactive: false
      })
      }else if(!this.state.bankactive){
        this.setState ({
          bankactive: true,
          selecteditems:[...this.state.selecteditems,e.target.value]
        })
  
      }
  
  }

  railways=(e)=>{
    if(this.state.Railwaysactive){
      this.setState ({
        Railwaysactive: false
      })
      }else if(!this.state.Railwaysactive){
        this.setState ({
          Railwaysactive: true,
          selecteditems:[...this.state.selecteditems,e.target.value]
        })
      }
  }

  delete=(index)=>{
    this.state.data.splice(index,1)
    this.setState({
    data:[...this.state.data]
    })
  }

  name=(e)=>{
    this.setState({
      name:e.target.value
    })
    
  }

  gender=(e)=>{
    this.setState({
      age:e.target.value
    })
  }
  cancle=()=>{
    this.setState({
      name:"",
      age:"",
      transgender:"",
      itactive:false,
      bankactive:false,
      Bussinessavtive:false,
      Railwaysactive:false,
    })
  }
  render(){
let  data = this.props.getdata.map((data,index)=>{
  let itemsdata = data.items.map((item)=>{
    return <div>
      {item}
    </div>
  })
      return <ul>
    
        <li  className="li">name : {data.name}</li>
        <li>age :{data.age}</li>
        <li>Aera of Intrest :{itemsdata}</li>
        <li><button id = {index} onClick = {()=>{this.delete(index)}}className="btndlt">delete</button></li>
      </ul>
    })

   
  return (
    <div className = "parentdiv">

      <div className = "divchild1">Name :<br/>
      <input type="text" placeholder="Enter name" value={this.state.name} onChange={this.name.bind(this)}/><br/>      
      </div>

      <div className = "divchild2">
        Age :<br/>
      <select onChange={this.gender.bind(this)} value={this.state.age}>
      <option>..select gender</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="transgender">Transgender</option>
      </select><br/>
      </div>

      <div className="divchild3">Aera of Intrest<br/>
      <input type="checkbox" checked={this.state.itactive}  value="IT" onChange={this.IT.bind(this)}/>
       <label>IT</label>
      <input type="checkbox" checked={this.state.Bussinessavtive} value="Bussiness" onChange={this.business.bind(this)}/>
      <label>Bussiness</label>
      <input type="checkbox" checked={this.state.bankactive} value="Banking" onChange={this.banking.bind(this)}/>
      <label> Banking</label>
      <input type="checkbox" checked={this.state.Railwaysactive} value="Railways" onChange={this.railways.bind(this)}/>
      <label for="vehicle3"> Railways</label>
      </div>

             
      
      <button onClick={this.submit} className = "btnsub">Submit
      </button> 
      <button onClick={this.props.onCancel} className="btncan" onClick={this.cancle}>Cancle</button>
      
      {data}

    </div>
  )
  }
}

let mapStateToProps=state=>{
  return{
  getdata:state.data
  }
}


let mapDispatchToProps=dispatch=>{
  return{
  sendData:(data)=>dispatch({type:"adddata",val:data}),
  }
}
export default connect(mapStateToProps,mapDispatchToProps)(App);
