let initailState = {
    data:[]
}

let reduser=(state=initailState,action)=>{
   if(action.type==="adddata"){
       return{
           ...state,
           data:state.data.concat(action.val)
       }

   }
   return state
}

export default reduser;